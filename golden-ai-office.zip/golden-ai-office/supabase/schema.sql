-- Skema awal GOLDEN AI OFFICE (dijalankan nanti di Supabase > SQL Editor).
create table if not exists agents (
  id text primary key,
  name text not null,
  role text not null,
  status text not null default 'Standby',
  current_task text
);

create table if not exists ledger (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  description text not null,
  amount numeric not null,            -- koreksi = transaksi pembalik, jangan hapus baris
  reverses_id bigint references ledger(id)
);

create table if not exists analyses (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  symbol text not null default 'XAUUSD',
  timeframe text not null,
  decision text not null check (decision in ('BUY','SELL','WAIT')),
  entry numeric, sl numeric, tp1 numeric, tp2 numeric, rr numeric,
  status text not null default 'pending'  -- pending / approved / rejected / redo
);

create table if not exists activity_log (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  agent text not null,
  message text not null
);

-- Wajib: aktifkan Row Level Security sebelum dipakai sungguhan.
alter table agents enable row level security;
alter table ledger enable row level security;
alter table analyses enable row level security;
alter table activity_log enable row level security;
