"use client";
import { useState } from "react";
import { Card, Badge } from "@/components/ui";

// Laporan contoh. Angka TIDAK bisa diubah Director: hanya setuju / tolak / minta ulang.
const REPORT = {
  decision: "WAIT",
  timeframe: "H1",
  reason: "Data pasar dan kalender berita belum terhubung, sehingga keputusan otomatis WAIT.",
  entry: null, sl: null, tp1: null, tp2: null, rr: null,
};

const rows = [
  ["Entry", REPORT.entry], ["Stop Loss", REPORT.sl], ["TP1 (50%)", REPORT.tp1], ["TP2 (50%)", REPORT.tp2], ["Risk/Reward", REPORT.rr],
];

export default function ReportReview() {
  const [status, setStatus] = useState("Menunggu keputusan Director");
  return (
    <Card title="Laporan Akhir Manager AI" right={<Badge>DEMO</Badge>}>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className="rounded-lg border border-gold-500/50 bg-gold-500/10 px-4 py-1.5 text-xl font-black tracking-widest text-gold-300">
          {REPORT.decision}
        </span>
        <span className="text-sm text-stone-400">XAUUSD · {REPORT.timeframe}</span>
      </div>
      <p className="mb-4 text-sm text-stone-300">{REPORT.reason}</p>
      <dl className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-5">
        {rows.map(([k, v]) => (
          <div key={k} className="rounded-xl border border-ink-500 bg-ink-900 p-3">
            <dt className="text-[11px] text-stone-500">{k}</dt>
            <dd className="mt-1 font-mono text-lg text-gold-300">{v ?? "—"}</dd>
          </div>
        ))}
      </dl>
      <div className="flex flex-wrap gap-2">
        <button onClick={() => setStatus("DISETUJUI (demo)")} className="rounded-lg bg-emerald-600/90 px-4 py-2 text-sm font-semibold text-white">Setuju</button>
        <button onClick={() => setStatus("DITOLAK (demo)")} className="rounded-lg bg-red-600/90 px-4 py-2 text-sm font-semibold text-white">Tolak</button>
        <button onClick={() => setStatus("MINTA ANALISIS ULANG (demo)")} className="rounded-lg border border-gold-500/50 px-4 py-2 text-sm font-semibold text-gold-300">Minta ulang</button>
      </div>
      <p className="mt-3 text-sm text-stone-400">Status: <span className="font-semibold text-gold-300">{status}</span></p>
      <p className="mt-1 text-xs text-stone-500">Director tidak dapat mengubah angka, hanya setuju, tolak, atau minta ulang.</p>
    </Card>
  );
}
