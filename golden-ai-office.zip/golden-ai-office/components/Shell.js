"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { NAV } from "@/lib/data";
import { cn } from "@/lib/utils";

function NavList({ onPick }) {
  const path = usePathname();
  return (
    <nav className="flex flex-col gap-1">
      {NAV.map((n) => {
        const active = n.href === "/" ? path === "/" : path.startsWith(n.href);
        return (
          <Link
            key={n.href}
            href={n.href}
            onClick={onPick}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition",
              active ? "bg-gold-500/15 font-semibold text-gold-300 ring-1 ring-gold-500/40" : "text-stone-400 hover:bg-ink-700 hover:text-stone-200"
            )}
          >
            <span className="w-5 text-center">{n.icon}</span>
            {n.label}
          </Link>
        );
      })}
    </nav>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-2">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 font-black text-black">G</div>
      <div className="leading-tight">
        <div className="text-sm font-extrabold tracking-widest text-gold-300">GOLDEN AI</div>
        <div className="text-[10px] tracking-[0.3em] text-stone-500">OFFICE</div>
      </div>
    </div>
  );
}

export default function Shell({ children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen lg:flex">
      {/* Sidebar desktop */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col gap-6 border-r border-gold-500/15 bg-ink-900 p-4 lg:flex">
        <Brand />
        <NavList />
        <div className="mt-auto rounded-xl border border-ink-500 bg-ink-800 p-3 text-xs text-stone-400">
          Mode: <span className="font-bold text-gold-300">ANALYSIS ONLY</span>
          <br />
          Tidak ada trading sungguhan.
        </div>
      </aside>

      {/* Header HP */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-gold-500/15 bg-ink-900/95 px-4 py-3 backdrop-blur lg:hidden">
        <Brand />
        <button
          aria-label="Menu"
          onClick={() => setOpen(true)}
          className="rounded-lg border border-gold-500/40 px-3 py-1.5 text-lg text-gold-300"
        >
          ☰
        </button>
      </header>

      {/* Drawer HP */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/70" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-72 max-w-[85%] overflow-y-auto border-l border-gold-500/30 bg-ink-900 p-4">
            <div className="mb-4 flex items-center justify-between">
              <Brand />
              <button onClick={() => setOpen(false)} className="px-2 text-xl text-stone-400">✕</button>
            </div>
            <NavList onPick={() => setOpen(false)} />
          </div>
        </div>
      )}

      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
    </div>
  );
}
