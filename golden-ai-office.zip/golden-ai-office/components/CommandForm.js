"use client";
import { useState } from "react";
import { Card, Badge, Empty } from "@/components/ui";

const TF = ["M1", "M5", "M15", "H1", "H4"];

export default function CommandForm() {
  const [text, setText] = useState("");
  const [tf, setTf] = useState("H1");
  const [list, setList] = useState([]);

  function send(e) {
    e.preventDefault();
    if (!text.trim()) return;
    setList([{ id: Date.now(), text: text.trim(), tf, time: new Date().toLocaleTimeString("id-ID") }, ...list]);
    setText("");
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Kirim perintah ke Manager AI" right={<Badge>DEMO</Badge>}>
        <form onSubmit={send} className="space-y-3">
          <div>
            <label className="mb-1 block text-xs text-stone-400">Instrumen</label>
            <div className="rounded-lg border border-ink-500 bg-ink-900 px-3 py-2 text-sm text-gold-300">XAUUSD</div>
          </div>
          <div>
            <label className="mb-1 block text-xs text-stone-400">Timeframe</label>
            <div className="flex flex-wrap gap-2">
              {TF.map((t) => (
                <button
                  type="button"
                  key={t}
                  onClick={() => setTf(t)}
                  className={`rounded-lg border px-3 py-1.5 text-sm ${tf === t ? "border-gold-400 bg-gold-500/20 text-gold-300" : "border-ink-500 text-stone-400"}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs text-stone-400">Perintah</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={4}
              placeholder="Contoh: Analisis XAUUSD H1, beri BUY/SELL/WAIT lengkap dengan entry, SL, TP1, TP2."
              className="w-full rounded-lg border border-ink-500 bg-ink-900 p-3 text-sm text-stone-200 outline-none focus:border-gold-500"
            />
          </div>
          <button className="w-full rounded-xl bg-gradient-to-r from-gold-400 to-gold-600 py-2.5 text-sm font-bold text-black active:scale-[.99]">
            Kirim perintah
          </button>
          <p className="text-xs text-stone-500">Belum terhubung ke model AI. Perintah hanya disimpan sementara di layar ini.</p>
        </form>
      </Card>

      <Card title="Perintah terkirim">
        {list.length === 0 ? (
          <Empty>Belum ada perintah.</Empty>
        ) : (
          <ul className="space-y-2">
            {list.map((c) => (
              <li key={c.id} className="rounded-xl border border-ink-500 bg-ink-900 p-3 text-sm">
                <div className="mb-1 flex items-center gap-2 text-xs text-stone-500">
                  <span>{c.time}</span> <Badge tone="gray">{c.tf}</Badge> <Badge>MENUNGGU AI</Badge>
                </div>
                {c.text}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
