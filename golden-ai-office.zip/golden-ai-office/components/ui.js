import { cn } from "@/lib/utils";

export function Card({ title, right, children, className }) {
  return (
    <section className={cn("rounded-2xl border border-gold-500/20 bg-ink-800 p-4 shadow-gold sm:p-5", className)}>
      {(title || right) && (
        <header className="mb-3 flex items-center justify-between gap-2">
          {title && <h2 className="text-sm font-semibold uppercase tracking-wider text-gold-400">{title}</h2>}
          {right}
        </header>
      )}
      {children}
    </section>
  );
}

export function Badge({ children, tone = "gold" }) {
  const tones = {
    gold: "border-gold-500/40 bg-gold-500/10 text-gold-300",
    gray: "border-ink-500 bg-ink-700 text-stone-400",
    green: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    red: "border-red-500/40 bg-red-500/10 text-red-300",
  };
  return (
    <span className={cn("inline-block rounded-full border px-2 py-0.5 text-[10px] font-bold tracking-wider", tones[tone])}>
      {children}
    </span>
  );
}

export function PageTitle({ title, sub, badge }) {
  return (
    <div className="mb-5">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-2xl font-bold text-gold-300">{title}</h1>
        {badge && <Badge>{badge}</Badge>}
      </div>
      {sub && <p className="mt-1 text-sm text-stone-400">{sub}</p>}
    </div>
  );
}

export function Avatar({ initials }) {
  return (
    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gold-500/50 bg-gradient-to-br from-gold-400/20 to-gold-600/5 text-sm font-bold text-gold-300">
      {initials}
    </div>
  );
}

export function Empty({ children }) {
  return <p className="rounded-xl border border-dashed border-ink-500 p-6 text-center text-sm text-stone-500">{children}</p>;
}
