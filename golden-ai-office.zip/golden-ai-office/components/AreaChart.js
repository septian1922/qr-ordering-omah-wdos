import { demoSeries } from "@/lib/data";

export default function AreaChart() {
  const data = demoSeries(72);
  const W = 800, H = 280, PX = 8, PY = 20;
  const min = Math.min(...data), max = Math.max(...data);
  const x = (i) => PX + (i * (W - PX * 2)) / (data.length - 1);
  const y = (v) => PY + (1 - (v - min) / (max - min || 1)) * (H - PY * 2);
  const line = data.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const area = `${line} L${x(data.length - 1).toFixed(1)},${H - PY} L${x(0).toFixed(1)},${H - PY} Z`;
  const grid = [0, 1, 2, 3].map((i) => PY + (i * (H - PY * 2)) / 3);

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Chart XAUUSD contoh (DEMO)">
        <defs>
          <linearGradient id="goldFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#d4a72c" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#d4a72c" stopOpacity="0" />
          </linearGradient>
        </defs>
        {grid.map((g) => (
          <line key={g} x1={PX} x2={W - PX} y1={g} y2={g} stroke="#2a2a2a" strokeDasharray="4 6" />
        ))}
        <path d={area} fill="url(#goldFill)" />
        <path d={line} fill="none" stroke="#e8c25a" strokeWidth="2.5" strokeLinejoin="round" />
      </svg>
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <span className="rotate-[-12deg] text-5xl font-black tracking-[0.4em] text-gold-500/15 sm:text-7xl">DEMO</span>
      </div>
    </div>
  );
}
