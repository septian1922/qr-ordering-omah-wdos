import { PageTitle, Card, Badge } from "@/components/ui";
import { COMPANY, LEDGER } from "@/lib/data";
import { formatG } from "@/lib/utils";

export const metadata = { title: "Finance · GOLDEN AI OFFICE" };

export default function Page() {
  return (
    <>
      <PageTitle title="Finance" sub="Buku kas perusahaan (virtual)" badge="DEMO" />
      <div className="mb-4 grid gap-4 sm:grid-cols-3">
        <Card title="Saldo"><div className="text-3xl font-black text-gold-300">{formatG(COMPANY.balance)}</div></Card>
        <Card title="Modal Awal"><div className="text-3xl font-black text-stone-200">{formatG(COMPANY.startBalance)}</div></Card>
        <Card title="Profit / Rugi"><div className="text-3xl font-black text-stone-200">{formatG(COMPANY.balance - COMPANY.startBalance)}</div></Card>
      </div>
      <Card title="Buku Kas" right={<Badge>DEMO</Badge>}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[420px] text-left text-sm">
            <thead className="text-xs text-stone-500">
              <tr><th className="py-2">Tanggal</th><th>Keterangan</th><th className="text-right">Jumlah</th></tr>
            </thead>
            <tbody>
              {LEDGER.map((l) => (
                <tr key={l.id} className="border-t border-ink-600">
                  <td className="py-2 text-stone-400">{l.date}</td>
                  <td>{l.desc}</td>
                  <td className="text-right font-mono text-gold-300">{formatG(l.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-stone-500">Koreksi dilakukan dengan transaksi pembalik. Riwayat tidak dihapus.</p>
      </Card>
    </>
  );
}
