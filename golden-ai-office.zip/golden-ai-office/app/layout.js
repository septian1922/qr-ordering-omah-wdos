import "./globals.css";
import Shell from "@/components/Shell";

export const metadata = {
  title: "GOLDEN AI OFFICE",
  description: "Perusahaan trading virtual 6 AI Agent untuk analisis XAUUSD (Analysis Only)",
};

export const viewport = { width: "device-width", initialScale: 1, themeColor: "#050505" };

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className="antialiased">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
