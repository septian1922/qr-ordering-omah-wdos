import { Card, Badge, PageTitle, Avatar } from "@/components/ui";
import AreaChart from "@/components/AreaChart";
import { AGENTS, ACTIVITIES, COMPANY } from "@/lib/data";
import { formatG } from "@/lib/utils";

export default function Dashboard() {
  return (
    <>
      <PageTitle title="Dashboard" sub="Ringkasan kantor GOLDEN AI OFFICE" badge="DEMO" />

      <div className="mb-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card title="Saldo Perusahaan" className="sm:col-span-2">
          <div className="text-4xl font-black text-gold-300 sm:text-5xl">{formatG(COMPANY.balance)}</div>
          <p className="mt-1 text-xs text-stone-500">Saldo virtual awal. Bukan uang sungguhan.</p>
        </Card>
        <Card title="Mode">
          <div className="text-xl font-bold text-gold-300">{COMPANY.mode}</div>
          <p className="mt-1 text-xs text-stone-500">Tidak ada trading sungguhan.</p>
        </Card>
        <Card title="Instrumen">
          <div className="text-xl font-bold text-gold-300">{COMPANY.symbol}</div>
          <p className="mt-1 text-xs text-stone-500">1 pip = {formatG(COMPANY.pipValue)}</p>
        </Card>
      </div>

      <Card title="Chart XAUUSD" right={<Badge>DEMO</Badge>} className="mb-4">
        <AreaChart />
        <p className="mt-2 text-xs text-stone-500">Data contoh, belum terhubung ke data pasar. Jangan dipakai untuk keputusan.</p>
      </Card>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Enam AI Agent" className="xl:col-span-2">
          <ul className="grid gap-3 sm:grid-cols-2">
            {AGENTS.map((a) => (
              <li key={a.id} className="flex items-start gap-3 rounded-xl border border-ink-500 bg-ink-900 p-3">
                <Avatar initials={a.initials} />
                <div className="min-w-0">
                  <div className="font-semibold text-stone-100">{a.name}</div>
                  <div className="text-xs text-gold-400">{a.role}</div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-2">
                    <Badge tone="gray">{a.status.toUpperCase()}</Badge>
                    <span className="text-xs text-stone-500">{a.task}</span>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Aktivitas Perusahaan" right={<Badge>DEMO</Badge>}>
          <ul className="space-y-3">
            {ACTIVITIES.map((x) => (
              <li key={x.id} className="border-l-2 border-gold-500/40 pl-3 text-sm">
                <div className="text-xs text-stone-500">{x.time} · {x.agent}</div>
                <div className="text-stone-300">{x.text}</div>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
