import { PageTitle, Card, Badge } from "@/components/ui";
import { AGENTS } from "@/lib/data";
import { formatG } from "@/lib/utils";

export const metadata = { title: "Salary & Bonus · GOLDEN AI OFFICE" };

export default function Page() {
  return (
    <>
      <PageTitle title="Salary & Bonus" sub="Gaji dan bonus karyawan AI (virtual)" badge="DEMO" />
      <Card title="Daftar Karyawan" right={<Badge>BELUM DIATUR</Badge>}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[480px] text-left text-sm">
            <thead className="text-xs text-stone-500">
              <tr><th className="py-2">Karyawan</th><th>Jabatan</th><th className="text-right">Gaji</th><th className="text-right">Bonus</th></tr>
            </thead>
            <tbody>
              {AGENTS.map((a) => (
                <tr key={a.id} className="border-t border-ink-600">
                  <td className="py-2 font-medium">{a.name}</td>
                  <td className="text-stone-400">{a.role}</td>
                  <td className="text-right font-mono text-stone-400">{formatG(0)}</td>
                  <td className="text-right font-mono text-stone-400">{formatG(0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-stone-500">Skema gaji dan bonus akan ditentukan di tahap berikutnya.</p>
      </Card>
    </>
  );
}
