import { PageTitle, Card, Badge, Empty } from "@/components/ui";

export const metadata = { title: "Trading History · GOLDEN AI OFFICE" };

export default function Page() {
  return (
    <>
      <PageTitle title="Trading History" sub="Riwayat transaksi virtual setelah laporan disetujui Director" badge="DEMO" />
      <Card title="Transaksi Virtual" right={<Badge tone="gray">0 TRANSAKSI</Badge>}>
        <Empty>Belum ada transaksi. Transaksi virtual dibuat setelah Director menyetujui laporan.</Empty>
        <ul className="mt-4 space-y-1 text-xs text-stone-500">
          <li>• Entry = tengah zona. SL tidak dipindah ke break-even setelah TP1.</li>
          <li>• TP1 menutup 50% posisi virtual, TP2 menutup 50% sisanya.</li>
          <li>• Entry kedaluwarsa jika belum terisi dalam 24 candle timeframe analisis.</li>
        </ul>
      </Card>
    </>
  );
}
