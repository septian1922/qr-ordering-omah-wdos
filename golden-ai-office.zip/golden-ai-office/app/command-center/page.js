import { PageTitle } from "@/components/ui";
import CommandForm from "@/components/CommandForm";

export const metadata = { title: "Command Center · GOLDEN AI OFFICE" };

export default function Page() {
  return (
    <>
      <PageTitle title="Command Center" sub="Director memberi perintah kepada Manager AI" badge="DEMO" />
      <CommandForm />
    </>
  );
}
