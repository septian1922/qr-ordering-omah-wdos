import { PageTitle, Card, Badge, Avatar } from "@/components/ui";
import ReportReview from "@/components/ReportReview";
import { AGENTS } from "@/lib/data";

export const metadata = { title: "Analysis Room · GOLDEN AI OFFICE" };

export default function Page() {
  const analysts = AGENTS.filter((a) => a.id !== "manager");
  return (
    <>
      <PageTitle title="Analysis Room" sub="Ruang analisis lima analis dan laporan akhir Manager AI" badge="DEMO" />
      <div className="mb-4">
        <ReportReview />
      </div>
      <Card title="Opini Analis">
        <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {analysts.map((a) => (
            <li key={a.id} className="rounded-xl border border-ink-500 bg-ink-900 p-3">
              <div className="mb-2 flex items-center gap-3">
                <Avatar initials={a.initials} />
                <div>
                  <div className="text-sm font-semibold">{a.name}</div>
                  <Badge tone="gray">WAIT</Badge>
                </div>
              </div>
              <p className="text-xs text-stone-500">Belum ada analisis. Menunggu data sumber (BELUM TERHUBUNG).</p>
            </li>
          ))}
        </ul>
      </Card>
    </>
  );
}
