import { PageTitle, Card, Badge } from "@/components/ui";
import { COMPANY } from "@/lib/data";
import { supabaseConfigured } from "@/lib/supabase";
import { formatG } from "@/lib/utils";

export const metadata = { title: "Settings · GOLDEN AI OFFICE" };

function Row({ k, v, badge }) {
  return (
    <div className="flex items-center justify-between gap-3 border-t border-ink-600 py-3 first:border-0">
      <span className="text-sm text-stone-400">{k}</span>
      <span className="flex items-center gap-2 text-right text-sm font-semibold text-stone-200">{v} {badge}</span>
    </div>
  );
}

export default function Page() {
  return (
    <>
      <PageTitle title="Settings" sub="Pengaturan perusahaan dan koneksi layanan" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Aturan Perusahaan">
          <Row k="Mode" v={COMPANY.mode} />
          <Row k="Instrumen" v={COMPANY.symbol} />
          <Row k="Timeframe" v={COMPANY.timeframes.join(", ")} />
          <Row k="Saldo awal" v={formatG(COMPANY.startBalance)} />
          <Row k="1 pip" v={`${formatG(COMPANY.pipValue)} (harga $0,10)`} />
          <Row k="Berita berdampak tinggi" v="WAIT 30 menit sebelum & sesudah" />
          <Row k="Data kurang" v="WAIT" />
        </Card>
        <Card title="Koneksi Layanan">
          <Row k="Supabase (database)" v={supabaseConfigured ? "Terkonfigurasi" : "Belum diisi"} badge={<Badge tone={supabaseConfigured ? "green" : "gray"}>{supabaseConfigured ? "SIAP" : "BELUM TERHUBUNG"}</Badge>} />
          <Row k="Data pasar XAUUSD" v="Belum dipilih" badge={<Badge tone="gray">BELUM TERHUBUNG</Badge>} />
          <Row k="Model AI (6 agent)" v="Belum dipilih" badge={<Badge tone="gray">BELUM TERHUBUNG</Badge>} />
          <Row k="Kalender berita" v="Belum dipilih" badge={<Badge tone="gray">BELUM TERHUBUNG</Badge>} />
        </Card>
      </div>
    </>
  );
}
