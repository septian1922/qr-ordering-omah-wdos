import { PageTitle, Card, Badge, Avatar } from "@/components/ui";
import { AGENTS } from "@/lib/data";

export const metadata = { title: "AI Employees · GOLDEN AI OFFICE" };

export default function Page() {
  return (
    <>
      <PageTitle title="AI Employees" sub="Enam karyawan AI dan tugasnya" badge="DEMO" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {AGENTS.map((a) => (
          <Card key={a.id}>
            <div className="mb-3 flex items-center gap-3">
              <Avatar initials={a.initials} />
              <div>
                <div className="font-bold text-stone-100">{a.name}</div>
                <div className="text-xs text-gold-400">{a.role}</div>
              </div>
            </div>
            <p className="mb-3 text-sm text-stone-400">{a.desc}</p>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="gray">{a.status.toUpperCase()}</Badge>
              <Badge>MODEL AI: BELUM TERHUBUNG</Badge>
            </div>
            <p className="mt-2 text-xs text-stone-500">Tugas: {a.task}</p>
          </Card>
        ))}
      </div>
    </>
  );
}
