import { PageTitle, Card, Badge } from "@/components/ui";
import { ACTIVITIES } from "@/lib/data";

export const metadata = { title: "Activity Log · GOLDEN AI OFFICE" };

export default function Page() {
  return (
    <>
      <PageTitle title="Activity Log" sub="Catatan seluruh aktivitas kantor" badge="DEMO" />
      <Card>
        <ul className="divide-y divide-ink-600">
          {ACTIVITIES.map((x) => (
            <li key={x.id} className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:gap-4">
              <span className="w-14 shrink-0 font-mono text-xs text-stone-500">{x.time}</span>
              <span className="w-44 shrink-0 text-sm font-semibold text-gold-300">{x.agent}</span>
              <span className="flex-1 text-sm text-stone-300">{x.text}</span>
              <Badge tone="gray">{x.tag}</Badge>
            </li>
          ))}
        </ul>
      </Card>
    </>
  );
}
